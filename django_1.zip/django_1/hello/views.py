from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def home(request):
    return HttpResponse('Hey Manish, Have a good day')
def greet(request):
    return render(request,'greetings.html')


